# 三轮 CNOT → T 注入

打开 http://127.0.0.1:8793/index.html ，点击“播放三轮 CNOT → T 注入（摘要）”。也可单独选择三轮 CNOT、T 注入或工厂复产。全部28个实际窗口、工厂内部动作、设备Schedule均保留；摘要仅跳过显示时间。

17个data码块、下方4座工厂、769原子。六组CNOT后，F3的epoch0魔态实际消费到q16；清理后F3进入epoch1生产。其他三座工厂持有待消费库存。模拟动作总时长952465.5μs（不是编译耗时）。

动作/时序/资源/经典反馈、同carrier-token-epoch消费链和查看器检查通过。显式fake测量，无量子态模拟、无硬件运行；本次没有重复进行完整连续路径验收。两套AOD分别参与，但同时搬运尚未实现，不宣称完全异步设备并行。用户视觉验收待确认。

报告：viewer/acceptance.json；查看器检查：viewer/pipeline-viewer-checks.json；浏览器记录：browser-checks.json；44份导出文件哈希：file-hashes.json。原运行：artifacts/qualification/cnot-t-bottom-20261009/run-v1。历史失败与修复均保留。

服务停止后可从项目根目录运行：
`scripts/.venv/Scripts/python.exe -m http.server 8793 --bind 127.0.0.1 --directory artifacts/deliveries/cnot-t-bottom-20261009/viewer`
