'use strict';
const MANIFEST=window.COMPONENT_MANIFEST, $=id=>document.getElementById(id), NS='http://www.w3.org/2000/svg';
window.COMPONENT_DATA=window.COMPONENT_DATA||{};
let chosen=null,data=null,tracks=[],carriers=[],sites=[],boundaries=[],current=0,playing=false,last=null,selectedAtom=null,maxSpan=0,requested=0,playRange=null;
let motion=null,clockMap=null,view={zoom:1,x:0,y:0},screenScale=1,drag=null,schedule=null,scheduleWindow=null,scheduleCursor=null,renderModel=null;
let controlStep=0;
const fmt=v=>Number(v).toLocaleString('en-US',{maximumFractionDigits:2});
const bisect=(xs,v,get=x=>x)=>{let lo=0,hi=xs.length;while(lo<hi){const m=(lo+hi)>>>1;if(get(xs[m])<=v)lo=m+1;else hi=m;}return lo;};
function node(tag,attrs={},label){const e=document.createElementNS(NS,tag);for(const[k,v]of Object.entries(attrs))e.setAttribute(k,v);if(label!==undefined)e.textContent=label;return e;}
function html(tag,label){const e=document.createElement(tag);if(label!==undefined)e.textContent=label;return e;}
const names={move:'移动',pickup:'拾取',drop:'放回',measure:'测量',reset:'复位',gate:'门操作',classical:'经典计算',wait:'等待',rebind:'提交数据位映射'};
function stateAt(t){return data.atoms.map((a,i)=>{let x=a[2],y=a[3],carrier=a[4];const j=bisect(tracks[i],t,v=>v[0])-1;if(j>=0){const m=tracks[i][j],f=m[1]===m[0]?1:Math.min(1,Math.max(0,(t-m[0])/(m[1]-m[0])));[x,y]=motion.point(i,t,$('path-style').value||'xy');}const c=bisect(carriers[i],t,v=>v[0])-1;if(c>=0)carrier=carriers[i][c][1];let site=a[6]||a[1];const s=bisect(sites[i],t,v=>v[0])-1;if(s>=0)site=sites[i][s][1];return{id:a[0],qubit:a[1],site,x,y,carrier};});}
function activeAt(t,includeSkipped=false){const end=bisect(data.actions,t,a=>a[0]),start=bisect(data.actions,t-maxSpan-1e-8,a=>a[0]);return data.actions.slice(start,end).filter(a=>(includeSkipped||a[7]==='completed')&&(t<a[1]||(a[0]===a[1]&&t===a[0])));}
function displayOptions(){return{style:$('render-style').value||'reference',glow:$('show-glow').checked,traps:$('show-traps').checked,aod:$('show-aod').checked,transfers:$('show-transfers').checked,gates:$('show-gates').checked,trails:$('show-trails').checked,labels:$('show-labels').checked,grid:$('show-grid').checked,zones:$('show-zones').checked,scale:$('show-scale').checked,path:$('path-style').value||'xy'};}
function render(){if(!data)return;renderFleetAt((data.absolute_origin_us||0)+current);$('pipeline-clock').textContent='全程 '+fmt((data.absolute_origin_us||0)+current)+' / '+fmt(MANIFEST.pipeline.duration_us)+' μs';const scene=$('scene'),w=Math.max(300,scene.getBoundingClientRect().width),h=scene.getBoundingClientRect().height||470,state=stateAt(current),active=activeAt(current);
 const rendered=window.LabRenderer.draw({scene,node,d:data,model:renderModel,state,active,motion,current,view,options:displayOptions(),size:Number($('atom-size').value)||2.8,width:w,height:h,selected:selectedAtom,onSelect:i=>{selectedAtom=i;$('atom-select').value=String(i);render();}});screenScale=rendered.scale;
 const transfers=active.filter(a=>a[2]==='pickup'||a[2]==='drop');
 const countSLM=state.filter(a=>a.carrier==='SLM').length;$('carrier-counts').textContent=`SLM ${countSLM} 颗 · AOD ${state.length-countSLM} 颗`;
 $('transfer-panel').hidden=transfers.length===0;
 if(transfers.length){const a=transfers.find(a=>a[3].includes(selectedAtom))||transfers[0],f=window.LabRenderer.transfer(a[2],a[0],a[1],current);$('transfer-detail').textContent=`${f.direction} · ${a[3].length} 颗 · ${fmt(100*f.progress)}%`;$('transfer-fill').style.width=(100*f.progress)+'%';$('transfer-detail').setAttribute('data-progress',f.progress);}
 const transferAction=transfers.find(a=>a[3].includes(selectedAtom))||transfers[0];
 const pulse=active.find(a=>a[6]==='CZ');
 const secondsTo=t=>$('mode').value==='keyframe'?(clockMap.displayAt(t)-clockMap.displayAt(current))/1000/Number($('speed').value):(t-current)/(Number($('timebase').value)*Number($('speed').value));
 $('slm-transfer').setAttribute('data-active','false');$('aod-transfer').setAttribute('data-active','false');$('slm-transfer').textContent='SLM';$('aod-transfer').textContent='AOD';
 if(transferAction){const a=transferAction,f=window.LabRenderer.transfer(a[2],a[0],a[1],current),inMeasurement=a[3].some(i=>{const s=state[i],z=renderModel.regions?.measurement;return z&&s.y>=z[2]&&s.y<=z[3]&&(z[0]===null||s.x>=z[0])&&(z[1]===null||s.x<=z[1]);});$('activity-detail').textContent=`${f.direction} · ${a[3].length} 颗并行交接${inMeasurement?' · 测量接收阵列':''}\n坐标保持不动，承载转换中 ${fmt(f.progress*100)}%\n本动作 ${fmt(a[1]-a[0])} μs · 剩余 ${fmt(a[1]-current)} μs（当前速度下 ${fmt(secondsTo(a[1]))} 秒）`;$('slm-transfer').setAttribute('data-active',String(f.slm>=.5));$('aod-transfer').setAttribute('data-active',String(f.aod>=.5));$('slm-transfer').textContent=`SLM ${fmt(100*f.slm)}%`;$('aod-transfer').textContent=`AOD ${fmt(100*f.aod)}%`;}
 else if(pulse){$('activity-detail').textContent=`CZ · ${pulse[5].length} 对并行\n原子静止，保持当前 SLM / AOD 承载\n脉冲 ${fmt(pulse[1]-pulse[0])} μs · compute zone 红色表示共同照明`;}
 else if(active.some(a=>a[2]==='move')){$('activity-detail').textContent='AOD 承载移动中 · 位置按当前动作插值';$('aod-transfer').setAttribute('data-active','true');}
 else if(active.length){const a=active[0];$('activity-detail').textContent=`${a[6]||names[a[2]]||a[2]} 执行中 · 剩余 ${fmt(a[1]-current)} μs`;}
 else{const next=data.actions.find(a=>a[0]>current&&a[7]==='completed');$('activity-detail').textContent=next?`等待下一事件 · 还需 ${fmt(next[0]-current)} μs\n下一步：${next[6]||names[next[2]]||next[2]}`:'本组件完成';}
 const counts={};for(const a of active){const n=a[6]==='H'?'物理 H':a[6]||names[a[2]]||a[2];counts[n]=(counts[n]||0)+(a[2]==='gate'&&a[5].length?a[5].length:Math.max(1,a[3].length));}
 const skipped=activeAt(current,true).filter(a=>a[7]==='skipped');
 $('active').textContent=Object.entries(counts).map(([k,n])=>`${k} × ${n}`).join('　')||(skipped.length?`条件未满足：跳过 ${skipped.length} 个门动作`:current>=data.end?'本组件回放完成':'等待下一个实际事件');
 const phase=data.end===0&&data.frame_events?.length?data.phases[Math.max(0,controlStep-1)]:data.phases.findLast(p=>p.start_us<=current)||data.phases[0];if(phase){$('phase').value=phase.id;$('phase-note').textContent=(phase.note||'')+(playRange?' · 仅播放选中阶段':' · 播放完整组件');}
 $('clock').textContent=`${fmt(current)} / ${fmt(data.end)} μs`;$('scrub').value=String($('mode').value==='keyframe'?clockMap.displayAt(current):current);updateMotionInfo(active);
 const fi=Math.max(0,bisect(boundaries,current)-1);$('frame-status').textContent=`关键帧 ${Math.min(fi+1,boundaries.length)} / ${boundaries.length}`;
 const published=bisect(data.results||[],current,r=>r.ready_us),recent=(data.results||[]).slice(Math.max(0,published-4),published);
 const resultText=r=>typeof r.value==='object'?`${r.value.status==='success'?'成功':'失败'}${r.value.factors?.length?' · '+r.value.factors.join(' × '):' · '+r.value.reason}`:String(r.value);
 $('result-status').textContent=`已发布 ${published} 个 fake / 派生结果`+(recent.length?' · '+recent.map(r=>`${r.id.split('/').at(-1)} = ${resultText(r)}`).join('；'):'');
 if(selectedAtom!==null){const a=state[selectedAtom];$('atom-detail').textContent=`原子 ${a.id} · 物理身份 ${a.qubit} · 当前数据位 ${a.site} · (${fmt(a.x)}, ${fmt(a.y)}) μm · ${a.carrier} · ${data.atoms[selectedAtom][5]} AOD` ;}
 renderSchedule();renderClifford();
 renderLogicalPhase(active,phase);
 const sids=[...new Set(active.flatMap(a=>a[8].map(i=>data.sources[i])))];$('source').textContent=sids.length?sids.join('\n'):'当前没有活动操作；点击“下一移动 / 下一 CZ / 下一测量”可定位来源。';
}
function renderLogicalPhase(active,phase){
 const ids=[...new Set(active.flatMap(a=>a[8]))],rows=new Map();
 for(const i of ids){const m=data.source_meta?.[i];if(!m)continue;const key=m.blocks.map(b=>b.replace('factory0:','')).join(' ↔ ')+' · '+m.label+(m.round==null?'':` · 第 ${m.round+1} 轮`);if(!rows.has(key))rows.set(key,new Set());rows.get(key).add(m.source_gate);}
 const actual=[...new Set(active.map(a=>a[6]||names[a[2]]||a[2]))].join(' / ');
 $('logical-phase-detail').textContent=(phase?.label||'')+'\n'+([...rows].map(([k,g])=>k+' · 源 '+[...g].join('/')).join('\n')||'当前无活动源操作')+(actual?'\n当前物理动作：'+actual:'');
 const sids=new Set(ids.map(i=>data.sources[i])),front=(data.joint_frontiers||[]).find(f=>f.selected_source_ids.some(i=>sids.has(i)));
 $('frontier-detail').textContent=front?JSON.stringify({候选门数:front.candidate_source_ids.length,本批门数:front.selected_source_ids.length,延后原因:front.deferred,未选原因:front.unselected,候选冲突证据:front.unselected_details,回执:front.decision_hash},null,2):'本动作不属于两比特门选批；源依赖与设备占用见模块记录。';
}
function setTime(t){current=Math.min(data.end,Math.max(0,Number(t)));render();}
function renderClifford(){
 const events=data.frame_events||[];$('clifford-panel').hidden=!events.length;if(!events.length)return;
 const index=data.end===0?controlStep-1:events.findLastIndex(e=>e.end_us<=current);
 const event=index>=0?events[index]:null,frames=event?.after||events[0].before;
 $('clifford-event').value=String(index+1);
 $('clifford-note').textContent=event?`${event.requested_gate} · ${event.software_only?'软件帧更新，硬件 0 μs':`物理实现 ${fmt(event.hardware_duration_us)} μs`}`:'入口帧 · 原子保持原位';
 const pending=events.find(e=>e.time_us<=current&&e.end_us>current);
 if(pending?.materialized_blocks?.length)$('clifford-note').textContent=`${pending.requested_gate} 指令执行中 · 下方为指令入口帧，出口帧在整条指令提交后显示；物理兑现与协议动作正在按记录执行。`;
 $('clifford-state').textContent=Object.entries(frames).map(([block,f])=>block+' · F = '+(f.word.join(' → ')||'I')+'\n'+Object.entries(f.observable_pullback).map(([p,v])=>`算法 ${p} → 物理 ${v.sign<0?'−':''}${v.axis}`).join('，')).join('\n\n');
 if(data.end===0){$('active').textContent=event?'逻辑 H：已更新软件帧':'软件帧演示 · 点击播放或下一帧更新';$('activity-detail').textContent='原子位置与载体不变 · 无物理动作';$('frame-status').textContent=`控制步骤 ${index+1} / ${events.length} · 0 μs`;}
}
$('clifford-next').onclick=()=>{if(!data)return;const events=data.frame_events||[];controlStep=(controlStep+1)%(events.length+1);if(data.end===0)render();else if(controlStep)jump(events[controlStep-1].end_us);};
$('clifford-event').onchange=()=>{controlStep=Number($('clifford-event').value);if(data.end===0)render();else jump(controlStep?data.frame_events[controlStep-1].end_us:0);};
function playState(){$('play').textContent=playing?'暂停':'播放';last=null;}
function jump(t){playing=false;if(playRange&&(Number(t)<playRange.start_us||Number(t)>playRange.end_us))playRange=null;playState();setTime(t);}
function jumpKind(kind){const a=data.actions.find(a=>a[0]>current+1e-8&&a[7]==='completed'&&(kind==='CZ'?a[6]==='CZ':a[2]===kind));if(a)jump(a[0]);}
function prepare(d){data=d;controlStep=0;$('clifford-event').replaceChildren();const initialControl=html('option','入口帧');initialControl.value='0';$('clifford-event').appendChild(initialControl);(d.frame_events||[]).forEach((e,i)=>{const o=html('option',`${i+1}. ${e.requested_gate} · ${fmt(e.end_us)} μs`);o.value=String(i+1);$('clifford-event').appendChild(o);});motion=window.MotionPreview.create(d,{clearance:Number($('clearance').value)||1});clockMap=window.MotionPreview.timeline(d);renderModel=window.LabRenderer.prepare(d,motion,window.COMPONENT_ZONES?.[d.id]);view={zoom:1,x:0,y:0};tracks=d.atoms.map(()=>[]);carriers=d.atoms.map(()=>[]);sites=d.atoms.map(()=>[]);maxSpan=0;for(const a of d.actions){if(a[7]!=='completed')continue;maxSpan=Math.max(maxSpan,a[1]-a[0]);for(const m of a[4])tracks[m[0]].push([a[0],a[1],...m.slice(1)]);for(const b of a[9]||[])sites[b[0]].push([a[1],b[2]]);if(a[2]==='pickup'||a[2]==='drop')for(const i of a[3])carriers[i].push([a[1],a[2]==='pickup'?'AOD':'SLM']);}for(const xs of tracks)xs.sort((a,b)=>a[0]-b[0]);for(const xs of carriers)xs.sort((a,b)=>a[0]-b[0]);for(const xs of sites)xs.sort((a,b)=>a[0]-b[0]);boundaries=clockMap.cuts;configureClock();$('phase').replaceChildren();for(const p of d.phases){const op=html('option',p.label);op.value=p.id;$('phase').appendChild(op);}selectedAtom=null;$('atom-detail').textContent='点击原子查看身份与当前位置';setTime(0);}
function showRow(row){window.COMPONENT_DATA={};scheduleCache.clear();$('call-select').value=row.id;$('landing').hidden=true;$('viewer-page').hidden=false;$('breadcrumb').textContent=row.category+' / '+row.label;chosen=row;const token=++requested;schedule=null;scheduleWindow=null;playing=false;playState();$('title').textContent=row.label;$('description').textContent=row.description;$('qualification').textContent='读取编译轨迹…';$('error').hidden=true;for(const e of document.querySelectorAll('.item'))e.setAttribute('aria-pressed',String(e.dataset.id===row.id));
 try{if(window.history?.replaceState&&window.location)window.history.replaceState(null,'','#'+encodeURIComponent(row.id));}catch{}
 playRange=null;
 data=null;$('scene').replaceChildren();$('active').textContent='正在载入实际轨迹';$('result-status').textContent='';for(const id of ['play','start','prev','next','move','cz','measure','phase','scrub'])$(id).disabled=true;
 $('metrics').replaceChildren();for(const [v,l]of [[row.physical_operations,'物理操作'],[`${row.executed_action_count} / ${row.action_count}`,'执行 / 计划动作'],[row.atom_count,'原子'],[fmt(row.duration_us)+' μs','模型时长']]){const span=html('span');span.appendChild(html('strong',String(v)));span.appendChild(html('span',l));$('metrics').appendChild(span);}
 $('scope').textContent=row.scope;$('links').replaceChildren();for(const ref of row.links||[]){const a=html('a',ref.label);a.href=ref.href;a.target='_blank';a.rel='noopener';$('links').appendChild(a);}
 async function ready(){try{if(token!==requested)return;const d=window.COMPONENT_DATA[row.data_id];if(!d)return;const rawSchedule=await loadSchedule(row.id);if(token!==requested)return;schedule=window.ResourceSchedule.create(rawSchedule);scheduleWindow=null;prepare(d);if(pendingHighlight){const h=pendingHighlight;pendingHighlight=null;playRange={start_us:h.start_us,end_us:h.end_us};$("mode").value="keyframe";configureClock();setTime(h.start_us);queueMicrotask(()=>{playing=true;playState();});}if(pipelineAutoplay){pipelineAutoplay=false;queueMicrotask(()=>{playing=true;playState();});}$('atom-select').replaceChildren();const none=html('option','未选择');none.value='';$('atom-select').appendChild(none);d.atoms.forEach((a,i)=>{const op=html('option',a[1]);op.value=String(i);$('atom-select').appendChild(op);});$('atom-select').value='';for(const id of ['play','start','prev','next','move','cz','measure','phase','scrub'])$(id).disabled=false;$('qualification').textContent=(row.version_status||'历史冻结工件')+' · 当前窗口检查通过 · 视觉待验';prepareModules(row,d);playing=false;playState();}catch(e){if(token===requested){$('error').hidden=false;$('error').textContent='设备时间表或轨迹加载失败：'+e.message;}}}
 const packed=document.getElementById('packed-'+row.data_id);
 if(window.COMPONENT_DATA[row.data_id])ready();else if(packed&&typeof DecompressionStream==='function'){
   const bytes=Uint8Array.from(atob(packed.textContent.trim()),c=>c.charCodeAt(0));
   new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text().then(raw=>{window.COMPONENT_DATA[row.data_id]=JSON.parse(raw);ready();}).catch(()=>{if(token===requested){$('error').hidden=false;$('error').textContent='内置轨迹解压失败，请从同目录 index.html 打开。';}});
 }else{const script=document.createElement('script');script.src=row.data_path;script.onload=ready;script.onerror=()=>{if(token===requested){$('error').hidden=false;$('error').textContent='轨迹文件未加载。请保持整个演示目录完整，再重新打开窗口。';}};document.head.appendChild(script);}
}
const moduleNames={local_layer:'本地门/复位层',entangling_layer:'并行耦合层',readout_connector:'全局测量区连接',permute:'实际运输置换',classical:'经典反馈'};
function prepareModules(row,d){$('module-artifact').hidden=true;const s=row.module_stats;$('module-stats').textContent=s?`版本 ${row.implementation_version} · 首次叶子编译 ${s.leaf_compile_count} · 缓存命中 ${s.cache_hit_count} · 绑定 ${s.bind_count} · 新连接 ${s.connector_compile_count} · 布局搜索 ${s.placement_search_count} · 路由搜索 ${s.routing_search_count}`:'此历史工件没有本轮模块化验收记录';$('module-select').replaceChildren();const none=html('option','选择子模块以定位动画');none.value='';$('module-select').appendChild(none);(d.modules||[]).forEach((m,i)=>{const o=html('option',`${i+1}. ${m.stage_id?m.stage_id+' / ':''}${moduleNames[m.kind]||m.kind} · ${m.module_hash.slice(0,10)}`);o.value=String(i);$('module-select').appendChild(o);});$('module-select').value='';$('module-detail').textContent=(d.geometry_variants||[]).length?'联合ZZ选点：\n'+JSON.stringify(d.geometry_variants,null,2):'模块引用只保存编译动作；测量值、token及epoch来自本次事件会话。';}
$('module-select').onchange=()=>{if(!data||$('module-select').value==='')return;const m=data.modules[Number($('module-select').value)];$('module-artifact').hidden=!m.artifact_ref;if(m.artifact_ref)$('module-artifact').href=m.artifact_ref.store+'/'+m.artifact_ref.file;playRange={start_us:m.start_us,end_us:m.end_us};jump(m.start_us);$('module-detail').textContent=`模块 ${m.module_hash}\n${fmt(m.start_us)}–${fmt(m.end_us)} μs · 本次绑定搜索 ${m.search_calls} · 全场景检查 ${m.checked_atoms} 颗\n依赖：${(m.dependency_ids||[]).join(', ')||'入口'}\n来源：\n${(m.source_ids||[]).join('\n')}`;};
function list(){const cat=$('catalog');cat.replaceChildren();let category='';const categories=new Set();for(const row of MANIFEST.components){if(category!==row.category){category=row.category;const h=html('div',category);h.className='category';h.dataset.category=category;cat.appendChild(h);}categories.add(category);const b=html('button');b.className='item';b.dataset.id=row.id;b.dataset.category=category;b.setAttribute('aria-pressed','false');b.appendChild(html('strong',row.label));b.appendChild(html('p',row.description));b.appendChild(html('small',`${row.atom_count} 原子 · ${fmt(row.duration_us)} μs　进入动画 →`));b.onclick=()=>showRow(row);cat.appendChild(b);}for(const c of categories){const op=html('option',c);op.value=c;$('category-filter').appendChild(op);}}
function filterCatalog(){const query=$('search').value.trim().toLowerCase(),category=$('category-filter').value,exact=MANIFEST.components.some(r=>r.id.toLowerCase()===query);let visible=0;const shown=new Set();for(const b of document.querySelectorAll('.item')){b.hidden=Boolean(category&&b.dataset.category!==category)||(exact?b.dataset.id.toLowerCase()!==query:!b.textContent.toLowerCase().includes(query)&&!b.dataset.id.toLowerCase().includes(query));if(!b.hidden){visible++;shown.add(b.dataset.category);}}for(const e of $('catalog').children)if(e.className==='category')e.hidden=!shown.has(e.dataset.category);$('catalog-empty').hidden=visible>0;}
$('search').oninput=filterCatalog;$('category-filter').onchange=filterCatalog;
function showLanding(){requested++;playing=false;playState();$('viewer-page').hidden=true;$('landing').hidden=false;try{window.history?.replaceState(null,'','#library');}catch{}$('search').focus?.();}
$('back').onclick=showLanding;
$('atom-select').onchange=()=>{if(!data)return;selectedAtom=$('atom-select').value===''?null:Number($('atom-select').value);if(selectedAtom===null)$('atom-detail').textContent='点击原子查看身份与当前位置';render();};
$('play').onclick=()=>{if(!data)return;if(data.end===0&&data.frame_events?.length){$('clifford-next').onclick();return;}playing=!playing;if(playing&&current>=(playRange?.end_us??data.end))setTime(playRange?.start_us??0);playState();};$('start').onclick=()=>{playRange=null;controlStep=0;jump(0);};$('scrub').oninput=()=>jump($('mode').value==='keyframe'?clockMap.modelAt(Number($('scrub').value)):$('scrub').value);$('phase').onchange=()=>{playRange=data.phases.find(p=>p.id===$('phase').value);if(data.end===0&&data.frame_events?.length)controlStep=data.phases.indexOf(playRange)+1;jump(playRange.start_us);};
$('prev').onclick=()=>{if(data?.end===0&&data.frame_events?.length){controlStep=Math.max(0,controlStep-1);render();}else jump(boundaries[Math.max(0,bisect(boundaries,current-1e-7)-1)]);};$('next').onclick=()=>{if(data?.end===0&&data.frame_events?.length){controlStep=Math.min(data.frame_events.length,controlStep+1);render();}else jump(boundaries[Math.min(boundaries.length-1,bisect(boundaries,current))]);};$('move').onclick=()=>jumpKind('move');$('cz').onclick=()=>jumpKind('CZ');$('measure').onclick=()=>jumpKind('measure');$('mode').onchange=()=>{playing=false;playState();configureClock();render();};
const scheduleCache=new Map();
async function loadSchedule(id){if(scheduleCache.has(id))return scheduleCache.get(id);const packed=window.COMPONENT_SCHEDULE_PACKED?.[id];if(!packed)throw Error('缺少 '+id+' 的资源记录');const bytes=Uint8Array.from(atob(packed),c=>c.charCodeAt(0));const value=JSON.parse(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text());scheduleCache.set(id,value);return value;}
function renderSchedule(){if(!schedule||!data)return;const chart=$('schedule'),width=Math.max(320,chart.getBoundingClientRect().width),left=118,right=16,rowHeight=22,top=25,height=top+schedule.lanes.length*rowHeight+6;
 const phase=data.phases.findLast(p=>p.start_us<=current)||data.phases[0],mode=$('schedule-mode').value||'follow',span=Number($('schedule-span').value)||1000;
 const anchor=mode==='follow'?Math.floor(current/(span/2))*(span/2):current,range=schedule.range(anchor,mode,span,phase),[start,end]=range,pw=Math.max(1,width-left-right),px=t=>left+(t-start)/(end-start)*pw;
 const key=[width,start,end,schedule.source.id].join('|');
 if(scheduleWindow!==key){scheduleWindow=key;chart.replaceChildren();chart.setAttribute('viewBox',`0 0 ${width} ${height}`);chart.style.height=height+'px';
 for(let k=0;k<=4;k++){const x=left+pw*k/4;chart.appendChild(node('line',{x1:x,x2:x,y1:18,y2:height,stroke:'var(--line)','stroke-width':.7}));chart.appendChild(node('text',{x,y:12,'text-anchor':k===4?'end':'start'},fmt(start+(end-start)*k/4)));}
 schedule.lanes.forEach((lane,i)=>{const y=top+i*rowHeight;chart.appendChild(node('text',{x:0,y:y+10},lane.label));chart.appendChild(node('rect',{x:left,y:y+1,width:pw,height:12,fill:'var(--bg)',rx:3}));const bins=new Uint8Array(Math.ceil(pw));for(const [a,b]of lane.spans){if(b<=start)continue;if(a>=end)break;const lo=Math.max(0,Math.floor(px(a)-left)),hi=Math.min(bins.length,Math.max(lo+1,Math.ceil(px(b)-left)));bins.fill(1,lo,hi);}let k=0;while(k<bins.length){if(!bins[k]){k++;continue;}let j=k+1;while(j<bins.length&&bins[j])j++;const box=node('rect',{x:left+k,y:y+1,width:j-k,height:12,rx:2,fill:lane.kind==='activity'?'#93aaa0':'#638477',class:'schedule-block','data-lane':lane.id});box.appendChild(node('title',{},`${lane.label} · 全程区间并集 ${fmt(lane.duration)} μs · ${fmt(lane.utilization*100)}%`));chart.appendChild(box);k=j;}
 });scheduleCursor=node('line',{x1:px(current),x2:px(current),y1:17,y2:height,stroke:'var(--text)','stroke-width':1.5,'data-playhead':'true'});chart.appendChild(scheduleCursor);}
 if(scheduleCursor){scheduleCursor.setAttribute('x1',px(current));scheduleCursor.setAttribute('x2',px(current));scheduleCursor.setAttribute('visibility',current>=start&&current<=end?'visible':'hidden');}
 $('schedule-range').textContent=`${fmt(start)}–${fmt(end)} μs`;
 const active=schedule.active(current);$('device-live').replaceChildren();for(const lane of active){const line=html('div');line.className='device-state';line.appendChild(html('span',lane.label));const status=html('span',lane.intervals.length?`${lane.intervals.length} 项${lane.kind==='activity'?'活动':'使用'}`:'无活动记录');status.className=lane.intervals.length?'busy':'idle';line.appendChild(status);$('device-live').appendChild(line);}
 chart.onclick=e=>{const rect=chart.getBoundingClientRect(),x=e.clientX-(rect.left||0),y=e.clientY-(rect.top||0),t=Math.max(start,Math.min(end,start+(x-left)/pw*(end-start))),lane=schedule.lanes[Math.floor((y-top)/rowHeight)];if(!lane){jump(t);return;}const hit=lane.intervals.find(v=>v[0]<=t&&t<v[1]);const nearby=hit||lane.intervals.find(v=>v[0]>=t&&v[0]<=end);jump(nearby?nearby[0]:t);if(nearby){const names=nearby[3].map(i=>schedule.source.resource_names[i]);$('schedule-detail').textContent=`${lane.label} · ${fmt(nearby[0])}–${fmt(nearby[1])} μs · 动作 ${nearby[2]+1} · ${names.slice(0,5).join(' / ')||'源动作活动时间'}`;}};
}
$('schedule-mode').onchange=$('schedule-span').onchange=()=>{scheduleWindow=null;render();};
function configureClock(){if(!data)return;if(data.end===0&&data.frame_events?.length){$('scrub').max='0';$('mode-note').textContent='软件控制步骤 · 硬件时钟保持 0 μs；播放或上一/下一事件展示帧更新。';$('timebase-label').hidden=true;return;}const key=$('mode').value==='keyframe';$('scrub').max=String(key?clockMap.displayEnd:data.end);$('timebase-label').hidden=key;$('mode-note').textContent=key?'关键帧演示 · 每个并发时间片放慢至 0.65–1.6 秒；按全局时钟保留重叠关系。时间条按展示时长展开。':`真实时间比例 · 1× = ${fmt(Number($('timebase').value))} μs / 屏幕秒；所有动作使用同一比例，不按组件总长归一化。`;$('prev').textContent=key?'上一关键帧':'上一事件';$('next').textContent=key?'下一关键帧':'下一事件';}
function updateMotionInfo(active){
 const moves=active.filter(a=>a[2]==='move'),original=$('path-style').value==='original';
 if(!moves.length){$('route-status').textContent=original?'原编译轨迹 · 按源时间线插值':'XY 预览就绪 · 移动时检查所有周围原子';$('motion-detail').textContent='当前无移动 · 可点击“下一移动”';return;}
 const routes=original?[]:moves.map(a=>motion.routeFor(a)),failed=routes.some(r=>r.fallback);
 $('route-status').textContent=original?'原编译轨迹 · 保留两轴同时变化':failed?'当前批次没有找到满足净距的 XY 插值，显示原轨迹（红色）。':`XY 连续间距检查通过 · 最小 ${fmt(Math.min(...routes.map(r=>r.minGap)))} μm · 阈值 ${fmt(motion.clearance)} μm`;
 const a=moves.find(a=>a[3].includes(selectedAtom))||moves[0],tr=a[4].find(t=>t[0]===selectedAtom)||a[4][0],route=original?null:motion.routeFor(a),path=route?route.paths.get(tr[0]):[[a[0],tr[1],tr[2]],[a[1],tr[3],tr[4]]];
 const length=path.slice(1).reduce((sum,p,i)=>sum+Math.hypot(p[1]-path[i][1],p[2]-path[i][2]),0),index=Math.max(0,Math.min(path.length-2,bisect(path,current,p=>p[0])-1)),p=path[index],q=path[index+1],speed=(q[0]>p[0])?Math.hypot(q[1]-p[1],q[2]-p[2])/(q[0]-p[0]):0;
 $('motion-detail').textContent=`${data.atoms[tr[0]][1]} · 同批 ${a[3].length} 颗\nA (${fmt(tr[1])}, ${fmt(tr[2])}) → B (${fmt(tr[3])}, ${fmt(tr[4])})\n${fmt(a[0])}–${fmt(a[1])} μs · 路长 ${fmt(length)} μm\n${original?'源轨迹':'预览'}当前速度 ${fmt(speed)} μm/μs · 进度 ${fmt(100*(current-a[0])/(a[1]-a[0]))}%`;
}
const optionIds=['show-glow','show-traps','show-aod','show-transfers','show-gates','show-trails','show-labels','show-grid','show-zones','show-scale'];
for(const id of optionIds)$(id).onchange=()=>render();
$('render-style').onchange=()=>render();
$('preset-lab').onclick=()=>{for(const id of optionIds)$(id).checked=!['show-labels','show-glow','show-trails'].includes(id);$('render-style').value='reference';render();};
$('preset-debug').onclick=()=>{for(const id of optionIds)$(id).checked=id!=='show-glow';$('render-style').value='technical';render();};
$('finish-action').onclick=()=>{if(!data)return;const xs=activeAt(current),transfer=xs.find(a=>a[2]==='pickup'||a[2]==='drop');if(transfer)jump(transfer[1]);else if(xs.length)jump(Math.min(...xs.map(a=>a[1])));else $('next').onclick();};
$('next-transfer').onclick=()=>{if(!data)return;const a=data.actions.find(a=>a[0]>current+1e-8&&a[7]==='completed'&&['pickup','drop'].includes(a[2]));if(a)jump(a[0]);};
$('atom-size').oninput=()=>{$('atom-size-value').textContent=$('atom-size').value+' μm';render();};
$('path-style').onchange=()=>render();$('clearance').onchange=()=>{if(data){motion=window.MotionPreview.create(data,{clearance:Number($('clearance').value)});render();}};
$('speed').onchange=()=>{last=null;if(data)render();};$('timebase').onchange=()=>{last=null;configureClock();if(data)render();};
$('end').onclick=()=>{if(data){playRange=null;controlStep=(data.frame_events||[]).length;jump(data.end);}};
$('seek').onclick=()=>{if(!data)return;const t=Number($('seek-time').value);if(Number.isFinite(t)&&t>=0&&t<=data.end){$('error').hidden=true;jump(t);}else{$('error').hidden=false;$('error').textContent=`请输入 0–${fmt(data.end)} μs 之间的时间。`;}};
function zoom(f){view.zoom=Math.max(.5,Math.min(30,view.zoom*f));render();}
$('zoom-in').onclick=()=>zoom(1.4);$('zoom-out').onclick=()=>zoom(1/1.4);$('fit').onclick=()=>{view={zoom:1,x:0,y:0};render();};
$('scene').onwheel=e=>{e.preventDefault();zoom(e.deltaY<0?1.15:1/1.15);};
$('scene').onpointerdown=e=>{drag={x:e.clientX,y:e.clientY};$('scene').setPointerCapture?.(e.pointerId);};
$('scene').onpointermove=e=>{if(!drag)return;view.x-=(e.clientX-drag.x)/screenScale;view.y+=(e.clientY-drag.y)/screenScale;drag={x:e.clientX,y:e.clientY};render();};
$('scene').onpointerup=$('scene').onpointercancel=()=>{drag=null;};
$('scene').onkeydown=e=>{if(e.key==='+'||e.key==='=')zoom(1.4);else if(e.key==='-')zoom(1/1.4);else if(e.key==='0')$('fit').onclick();};
document.addEventListener?.('visibilitychange',()=>{if(document.hidden){playing=false;playState();}});
function tick(stamp){if(playing&&data){if(last!==null){const stop=playRange?.end_us??data.end;setTime(window.MotionPreview.advance(current,stamp-last,{mode:$('mode').value,speed:Number($('speed').value),usPerSecond:Number($('timebase').value),stop,clock:clockMap}));if(current>=stop){playing=false;playState();if(playRange&&storyIndex>=0&&storyIndex+1<MANIFEST.highlights.length){playHighlight(storyIndex+1);}else if(!playRange&&$('follow-calls').checked)nextPipelineCall(1,true);}}last=stamp;}requestAnimationFrame(tick);}

let pipelineAutoplay=false;
function nextPipelineCall(delta,autoplay=false){const index=MANIFEST.components.findIndex(r=>r.id===chosen?.id),row=MANIFEST.components[index+delta];if(row){pipelineAutoplay=autoplay;showRow(row);}}
function renderFleetAt(t){
 const lines=[];
 for(const fid of ['F0','F1','F2','F3']){let state='待生产',epoch=0,target='';
  for(const e of window.FACTORY_DEMO.fleet.history){const when=e.time_us??e.receipt?.end_us;if(e.factory_id!==fid||when>t)continue;
   if(e.event==='production_started'){state='生产中';epoch=e.epoch;target='';}
   if(e.event==='output_ready')state='W4 库存就绪';
   if(e.event==='consumer_reserved'){state='供给 '+e.gate;target=' → '+e.target_patch;}
   if(e.event==='stage_committed'){state='已完成 '+e.receipt.stage_id;}
  }
  const active=window.FACTORY_DEMO.stages.find(s=>s.factory_id===fid&&s.start_us<=t&&t<s.end_us);
  if(active){state='执行 '+active.stage_id;epoch=active.epoch;}
  lines.push(fid+' · epoch '+epoch+' · '+state+target);
 }
 $('fleet-live').textContent=lines.join('\n');
 const done=Object.values(window.FACTORY_DEMO.logical).filter(s=>s.completed_us<=t).length;
 $('logical-progress').textContent=done+' / 7 个演示逻辑操作完成';
 $('magic-demand').textContent=window.FACTORY_DEMO.requests.filter(r=>r.submitted_us<=t).map(r=>r.completed_us<=t?r.target_patch+' · '+r.gate+' 消费完成':r.reserved_us<=t?r.factory_id+':W4 → '+r.target_patch+' · '+r.gate+' 消费中':r.target_patch+' · 等待 '+r.gate+' 资源 ('+fmt((t-r.submitted_us)/1000)+' ms)').join('\n');
}
for(const r of MANIFEST.components){const o=html('option',r.label);o.value=r.id;$('call-select').appendChild(o);}
$('call-select').onchange=()=>showRow(MANIFEST.components.find(r=>r.id===$('call-select').value));
$('call-prev').onclick=()=>nextPipelineCall(-1);$('call-next').onclick=()=>nextPipelineCall(1);


let pendingHighlight=null,storyIndex=-1;
function playHighlight(i){const h=MANIFEST.highlights[i];if(!h)return;storyIndex=i;pendingHighlight=h;showRow(MANIFEST.components.find(r=>r.id===h.window));}
$('story-play').onclick=()=>playHighlight(0);
$('view-all-routes').onclick=()=>{if(!data)return;data.bounds=data.full_bounds.slice();view={zoom:1,x:0,y:0};render();};
$('view-layout').onclick=()=>{if(!data)return;data.bounds=data.layout_bounds.slice();view={zoom:1,x:0,y:0};render();};
for(const [i,h]of MANIFEST.highlights.entries()){const b=document.createElement('button');b.textContent=h.label;b.onclick=()=>playHighlight(i);$('story-chapters').appendChild(b);}

new ResizeObserver(()=>{scheduleWindow=null;render();}).observe($('scene'));list();$('overall').textContent='17 码块 · 4 工厂 · 769 原子 · 7 逻辑操作';let initialId='library';try{initialId=decodeURIComponent((window.location?.hash||'#library').slice(1));}catch{}const initialRow=MANIFEST.components.find(r=>r.id===initialId);if(initialRow)showRow(initialRow);else showLanding();requestAnimationFrame(tick);
window.componentViewer={get data(){return data;},get current(){return current;},stateAt,setTime,jumpKind,showRow,manifest:MANIFEST,prepare,get motion(){return motion;},get clock(){return clockMap;},tick,get view(){return view;},showLanding,get schedule(){return schedule;},displayOptions,get screenScale(){return screenScale;}};
