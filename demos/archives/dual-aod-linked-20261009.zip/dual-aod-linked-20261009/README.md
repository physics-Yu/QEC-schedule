# 双 AOD · CNOT → T 注入

入口：[交互动画](http://127.0.0.1:8794/index.html)，或viewer/animation-library.html。

点击摘要播放；画布下方“定位双 AOD 同时搬运”直接停在143.5us，可同时查看两条设备Schedule。真实时间仍为100us/s，支持倍速与关键帧。

17 data码块、下方四工厂，769原子。保留全部89127原子动作：三轮共6个CNOT、完整工厂动作、F3输出向q16的T消费及F3下一epoch初始化。两套AOD工作重叠1294.5us，其中移动重叠112us；全程951160us。

只链接已编译动作与时间，原动作内容、A→B、时长、CZ批次和源身份不变。独立AOD并行抓取、data出程与magic回程重叠；共享CZ等待双方停稳。data完成后等待magic资源。四条工厂线共享同一magic AOD，库存满时等待消费。

这是原运行固定fake分支的重新排程预览，不是新运行时执行、量子采样或硬件结果。token/epoch引用原运行，未新建或复制到新运行态。旧执行与验收文件均保留原样。用户视觉验收pending；未重做全对连续路径资格。

检查：schedule-link.json、compilation-guard.json、viewer/pipeline-viewer-checks.json、browser-checks.json。生成入口scripts/relink_dual_aod_demo.py，定向测试scripts/test_dual_aod_link.py。原生编译、placement、routing、选批次入口均受零调用guard保护。
