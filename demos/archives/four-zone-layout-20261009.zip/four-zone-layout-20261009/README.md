# 两行四区布局

打开 http://127.0.0.1:8795/index.html，或本目录index.html。支持patch标签、trap、区域2Q光覆盖区、测量预留区、局部放大与点击patch角色。

上排：Compute（常规data门）／Processor（仅T注入交接）。
下排：Reloading（空预留）／Magic factory（四厂，每厂W0–W4与M）。

Y patch及旧probe已从新布局/资源配置移除，共减少72原子。保留17个data patch和24个factory patch，合计697原子。Processor没有常驻原子；没有凭空生成ready魔态。

这是布局与资源接口交付。四厂共同生产、两区独立2Q光为新配置的调度要求；尚未在这个布局上生成并验收生产时间表。旧769原子动画原样保留，不继承其执行/路径资格。

数据：layout.json、resource-contract.json。证据：checks.json、obsolete-resource-audit.json、compilation-guard.json、browser-checks.json。复现：scripts/build_four_zone_layout.py。测试：scripts/test_four_zone_layout.py。新接口：src/na_pipeline/runtime/four_zone_layout.py。
