"""Re-render the archived 2026-09-21 pilot without compiling any circuit."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

source_repo = Path(sys.argv[1]).resolve()
source = source_repo / 'artifacts/enola-figure2-2026-09-21/pilot'
destination = Path(__file__).resolve().parent
sys.path.insert(0, str(source_repo / 'src'))
from neutral_atom_experiments.enola_report import render_report

files = [source / 'provenance.json', *source.glob('graph_*.json')]
results = list(source.glob('*/result.json'))
assert len(results) == 9
for result in results:
    row = json.loads(result.read_text(encoding='utf-8'))
    assert row['status'] == 'completed'
    files.append(result)
    if row.get('animation'):
        files.append(result.parent / 'animation.html')
hashes = {}
for path in files:
    relative = path.relative_to(source)
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == hashlib.sha256(target.read_bytes()).hexdigest()
    hashes[str(relative)] = digest
render_report(destination)
assert (source / 'summary.csv').read_bytes() == (destination / 'summary.csv').read_bytes()
page = destination / 'index.html'
notice = '<p class="note">2026-10-09 重新出图；数据来自 2026-09-21 历史 pilot，未重新编译。每规模仅一个图实例。项目两组沿用当时旧硬件参数，不代表当前平台性能。</p>'
page.write_text(page.read_text(encoding='utf-8').replace('<section><h2>相同图实例',notice+'<section><h2>相同图实例',1),encoding='utf-8')
assert '@@' not in page.read_text(encoding='utf-8')
manifest = dict(regenerated_date='2026-10-09', source_date='2026-09-21',
    source_directory=str(source), completed_results=9, new_compilations=0,
    summary_csv_identical=True, copied_source_sha256=hashes,
    renderer_sha256=hashlib.sha256((source_repo/'src/neutral_atom_experiments/enola_report.py').read_bytes()).hexdigest(),
    scope='Historical Figure 2 inspired pilot; different native hardware; not current-project qualification',
    user_visual_acceptance='pending')
(destination/'regeneration-manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(dict(output=str(destination),results=9,copied_files=len(files),summary_csv_identical=True)))
