# Processor 完整 T 注入动画

入口：http://127.0.0.1:8796/viewer/index.html 。目录中分别打开m=0与m=1；支持关键帧/100us每秒、阶段跳转、Processor放大、完整测量区与设备Schedule。

输入条件：q16为待处理的任意逻辑态；F3:W4提供一份已编码A+。这里明确把工厂就绪输出作为本次注入测试的边界条件，没有重新运行完整蒸馏，也没有把旧token/测量/运行态复制成新运行。697原子、四区布局、两套AOD及分区Rydberg光按用户配置建模，不是已标定硬件执行。

完整闭环：D/W4搬入Processor → W4落SLM后运输控制权交给data AOD → 9对物理H-CZ-H构成逻辑CNOT → W4九位Z读出并计算逻辑奇偶 → m=1执行完整S-SE，m=0不修正 → D返回Compute → W4清理后等待magic AOD并归还F3。没有复位D的9个数据原子；W4始终是同一批载体。SLM停车位与AOD所有权显式检查。

F0/F1/F2共同实例化已编译的生产初始化动作，共享兼容magic AOD波形，期间与注入重叠。它们只完成初始化，不宣称完成蒸馏或生成ready魔态。F3等待交付的W4归还。后台三厂初始化结束后释放magic AOD，执行W4归还。因此两分支含后台工作的总时间均为25.696ms；D返回完成时间m=0为3.835ms，m=1为7.325ms。原硬件配置：pickup/drop100us、测量100us、结果发布5us、反馈1us。

验证：两个分支分别1541/1692条新事件；Kraus算符恒等式证明任意逻辑输入上的T语义；原9对CNOT与H目标、S-SE源门成员、逻辑测量反馈、资源互斥、分区照明准确配对、AOD行列映射、承载/控制权/SLM端口和最终697原子归还均检查。6项回归包含缺失S、缺失交接、错误门对、重复消费及错误测量分支拒绝。浏览器与用户视觉验收分别记录。

边界：使用新增的限定注入fake事件执行器，不等于主FactoryFleet全部迁移验收；未做噪声仿真或全对连续碰撞资格。运输为实际记录的横/竖分段指令，播放器默认播放原指令，不重新替换路径。区域CZ检查包含运动线段与照明区相交，测量运输从工厂右侧绕开Processor。背景与S-SE复用原编译门动作，连接几何重新绑定，原生编译/选批次/Enola搜索调用0。

文件：branch-*-plan.json.gz / branch-*-trace.json.gz / branch-*-checks.json；compilation-guard.json；source-hashes.json；viewer/viewer-checks.json；browser-checks.json。

复现：scripts/run_processor_injection_demo.py → scripts/test_processor_injection_demo.py → scripts/export_processor_injection_demo.py → scripts/check_processor_injection_viewer.js。
